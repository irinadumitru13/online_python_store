document.addEventListener("DOMContentLoaded", function() {
  console.log('hi there');
});