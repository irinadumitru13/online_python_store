#!/bin/bash

python /FashionStore/app.py